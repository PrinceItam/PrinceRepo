package Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class TestBase {
    public static Properties CONFIG = null;
    public static WebDriver driver = null;
    public void initialize() throws IOException {
        if (driver == null) {
//         This code will read the config property file
            CONFIG = new Properties();
            FileInputStream fn = new FileInputStream(System.getProperty("user.dir") + "/src/main/java/config/config.properties");
            CONFIG.load(fn);
//            initialize the WebDriver
            String browser = CONFIG.getProperty("browser");
            if ("Firefox".equals(browser)) {
                System.setProperty("webdriver.gecko.driver", "C:\\geckodriver.exe");
                driver = new FirefoxDriver();
            } else if ("IE".equals(browser)) {
                System.setProperty("webdriver.chrome.driver", "C:\\IeDriverServer.exe");
                driver = new InternetExplorerDriver();
            } else if ("chrome".equals(browser)) {
                System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
                driver = new ChromeDriver();
            }
            // driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        }

    }

}

